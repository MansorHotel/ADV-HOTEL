import datetime

from odoo import http, fields
from odoo.http import request


class HelpdeskBackend(http.Controller):

    @http.route('/hotel/fetch_dashboard_data', type="json", auth='user')
    def fetch_dashboard_data(self):
        room_booking = request.env['room.booking'].search_count([])
        hall_booking = request.env['hall.booking'].search_count([])
        laundry = request.env['hotel.laundry'].search_count([('state', 'in', ['request', 'process'])])
        transport = request.env['transport.service'].search_count([])
        housekeeping = request.env['housekeeping.service'].search_count([('state', 'in', ['assign', 'process'])])
        room_order = request.env['room.restaurant'].search_count([])
        table_booking = request.env['table.booking'].search_count([])
        order = request.env['table.order'].search_count([])
        employee = request.env['hr.employee'].search_count([])
        draft_inquiry = request.env['booking.inquiry'].search_count([('state', '=', 'draft')])
        available = request.env['table.number'].search_count([('state', '=', 'free')])
        today_date = fields.Date.today()
        yesterday_date = today_date - datetime.timedelta(days=1)
        tomorrow_date = today_date + datetime.timedelta(days=1)
        today_out = request.env['room.booking.line'].search_count(
            [('checkout_date', '>', yesterday_date), ('checkout_date', '<', tomorrow_date)])
        today_in = request.env['room.booking.line'].search_count(
            [('checkin_date', '>', yesterday_date), ('checkin_date', '<', tomorrow_date)])

        attendance = request.env['hr.attendance'].search_count(
            [('check_in', '>=', today_date), ('check_in', '<=', today_date)])

        leave = request.env['hr.leave'].search_count(
            [('date_from', '<=', today_date), ('date_to', '>=', today_date)])
        print(leave,'leave')
        leaves = request.env['hr.leave'].search(
            [('date_from', '<=', today_date), ('date_to', '>=', today_date)])
        for l in leaves:
            print(l.id,'ID')
            print(l.date_from,'from')
            print(l.date_to,'to')
        dashboard_data = {}
        user_id = request.env.user
        company_name = request.env.user.company_id.name

        # data_id = {}
        # data = {}
        # mc = []
        # booking_ids = request.env['hotel.reservation.booking'].search([('reservation_id.state', '=', 'confirm')],order='product_id')
        # room_ids = request.env['hotel.room.number'].search([('state', '=', 'free')],order='product_id')
        #
        # order = []
        # room = []
        # booking = []
        #
        # for datas in booking_ids:
        #     print(datas.room_id.name)
        #     order_data = {}
        #     # order_count.append(datas.id)
        #     order_data['reservation'] = datas.reservation_id.name if datas.reservation_id.name else ""
        #     order_data['partner'] = datas.partner_id.name if datas.partner_id.name else ""
        #     order_data['room'] = datas.room_id.name if datas.room_id.name else ""
        #     order_data['product'] = datas.product_id.name if datas.product_id.name else ""
        #     booking.append(order_data)
        #
        # for datas in room_ids:
        #     order_data = {}
        #     # order_count.append(datas.id)
        #     order_data['name'] = datas.name
        #     order_data['state'] = datas.state
        #     order_data['product'] = datas.product_id.name if datas.product_id.name else ""
        #     room.append(order_data)
        dashboard_data['today_in'] = today_in
        dashboard_data['today_out'] = today_out
        dashboard_data['draft_inquiry'] = draft_inquiry
        dashboard_data['room_booking'] = room_booking
        dashboard_data['company_name'] = company_name
        dashboard_data['hall_booking'] = hall_booking
        dashboard_data['laundry'] = laundry
        dashboard_data['transport'] = transport
        dashboard_data['housekeeping'] = housekeeping
        dashboard_data['room_order'] = room_order
        dashboard_data['table_booking'] = table_booking
        dashboard_data['order'] = order
        dashboard_data['available'] = available
        dashboard_data['employee'] = employee
        dashboard_data['attendance'] = attendance
        dashboard_data['leave'] = leave
        return dashboard_data
