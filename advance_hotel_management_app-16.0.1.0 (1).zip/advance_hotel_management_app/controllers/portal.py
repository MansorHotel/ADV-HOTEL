# -*- coding: utf-8 -*-
from datetime import datetime

from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager, get_records_pager
from odoo.http import request
from odoo import fields, http, _
from odoo.exceptions import AccessError, MissingError

attachments_ids = []


class HotelPortalAccount(CustomerPortal):

    @http.route(['/my/hotel'], type="http", auth="public", website=True)
    def create_hotel_order_form(self, **kw):
        partner = request.env["res.partner"].sudo().search([])
        data = {"partner": partner,
                }
        return request.render("advance_hotel_management_app.create_hotel_order_form", data)

    @http.route('/my/create_hotel', type='http', csrf=False, auth='public', website=True)
    def portal_create_hotel(self, **kw):
        arrival_date = kw.get('arrival_date')
        vals = {
            'inquiry_for': kw.get('inquiry_for'),
            'booking_time': int(kw.get('booking_time')),
            'person': int(kw.get('person')),
            'arrival_date': arrival_date,
            'user_id': request.env.user.id,
            'inquiry_name': kw.get('inquiry_name'),
            'email': kw.get('email'),
            'phone': kw.get('phone'),
        }
        booking_id = request.env['booking.inquiry'].sudo().create(vals)
        if booking_id:
            data = {
                "name": booking_id.name,
                "partner": booking_id.partner_id.name,
            }
            return request.render("advance_hotel_management_app.hotel_submitted", data)
        return {}

