# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class ResPartnerInherit(models.Model):
    _inherit = "res.partner"

    is_agent = fields.Boolean(string='Is Agent')
    is_driver = fields.Boolean(string='Is Driver')
    is_customer = fields.Boolean(string='Is Customer')
