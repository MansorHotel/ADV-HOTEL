# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class RoomStatus(models.Model):
    _name = "room.status"
    _description = "Room Status"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
    state = fields.Selection([('in', 'Checkin'), ('out', 'Checkout'), ('maintenance', 'Maintenance')], tracking=True,
                             string='Room Status', default='out')
