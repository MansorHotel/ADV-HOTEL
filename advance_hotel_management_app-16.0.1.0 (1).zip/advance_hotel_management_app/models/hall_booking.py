# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class HallBooking(models.Model):
    _name = "hall.booking"
    _description = "Hall Booking"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
    partner_id = fields.Many2one('res.partner', string="Customer", domain=[('is_customer', '=', True)],
                                 context={'default_is_customer': True})
    inquiry_id = fields.Many2one('booking.inquiry', string="Inquiry")
    start_date = fields.Datetime(string='Start Date')
    end_date = fields.Datetime(string='Departure Date', compute='compute_end_date')
    booking_time = fields.Integer(string="Total Hours")
    hall_id = fields.Many2one('hall.hall', string="Hall")
    any_deposit = fields.Boolean(string='Any Deposit')
    capacity = fields.Integer(string="Hall Capacity")
    price = fields.Float(string="Price/Hour", default=1)
    total_charge = fields.Float(string="Total Charge", compute="compute_total_charge")
    state = fields.Selection(
        [('draft', 'Draft'), ('confirm', 'Confirm'), ('complete', 'Complete'), ('cancel', 'Cancel')],
        string='State', tracking=True, default='draft')
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)
    invoice_id = fields.Many2one('account.move', string="Invoice")
    payment_state = fields.Selection(related='invoice_id.payment_state')
    deposit = fields.Float(string="Deposit")
    journal_id = fields.Many2one('account.journal', string="Payment Journal")
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)

    @api.onchange('hall_id')
    def onchange_hall_id(self):
        for rec in self:
            rec.price = rec.hall_id.price

    def action_create_invoice(self):
        # if self.any_deposit and not self.deposit_invoice_id:
        #     raise ValidationError("Please first create deposit invoice")

        name = 'Hall Booking' + ' - ' + self.name
        invoice_vals = self._prepare_invoice(self.total_charge, 1, name)
        account_move = self.env['account.move'].create(invoice_vals)

        if account_move:
            self.invoice_id = account_move
            self.state = 'complete'
            self.hall_id.state = 'free'
            domain = [('reconciled', '=', False)]
            account_move.action_post()
            lines = self.invoice_id.line_ids
            for payment in self.inquiry_id.payment_ids:
                # if payment.allocate:
                payment_lines = payment.payment_id.line_ids.filtered_domain(domain)
                for account in payment_lines.account_id:
                    (payment_lines + lines) \
                        .filtered_domain([('account_id', '=', account.id), ('reconciled', '=', False)]) \
                        .reconcile()
        form_id = self.env.ref('account.view_move_form').id
        return {'type': 'ir.actions.act_window',
                'name': _('Invoice'),
                'res_model': 'account.move',
                'view_mode': 'form',
                'views': [(form_id, 'form')],
                'domain': [('id', '=', account_move.id)],
                'res_id': account_move.id
                }

    def _prepare_invoice(self, price, quantity, name):
        """
        Prepare the dict of values to create the new invoice for a sales order. This method may be
        overridden to implement custom invoice generation (making sure to call super() to establish
        a clean extension chain).
        """
        company_id = self.env.user.company_id
        self.ensure_one()

        partner_id = self.partner_id
        invoice_lines = []
        vals = {
            'name': name,
            'price_unit': price,
            'quantity': quantity,
        }
        invoice_lines.append((0, 0, vals))

        invoice_vals = {
            'move_type': 'out_invoice',
            'invoice_user_id': self.env.user.id,
            'partner_id': partner_id.id,
            'invoice_origin': self.name,
            'invoice_line_ids': invoice_lines,
            'company_id': company_id.id,
        }
        return invoice_vals

    @api.depends('price', 'booking_time', 'any_deposit', 'deposit')
    def compute_total_charge(self):
        for rec in self:
            total_charge = rec.price * rec.booking_time
            if rec.any_deposit:
                total_charge = total_charge - rec.deposit
            rec.total_charge = total_charge

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_confirm(self):
        for rec in self:
            rec.state = 'confirm'
            rec.hall_id.state = 'booked'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('hall.booking') or _('New')
        result = super(HallBooking, self).create(vals)
        return result

    @api.depends('start_date', 'booking_time')
    def compute_end_date(self):
        for rec in self:
            if rec.start_date and rec.booking_time > 0:
                rec.end_date = rec.start_date + timedelta(hours=rec.booking_time)
            else:
                rec.end_date = False

    @api.constrains('booking_time', 'price', 'any_deposit', 'deposit')
    def _check_parent_id(self):
        if self.booking_time <= 0:
            raise ValidationError(_('Booking time should be greater then 0.'))
        if self.price <= 0:
            raise ValidationError(_('Price should be greater then 0.'))
        if self.any_deposit:
            if self.deposit <= 0:
                raise ValidationError(_('Deposit amount should be greater then 0.'))
