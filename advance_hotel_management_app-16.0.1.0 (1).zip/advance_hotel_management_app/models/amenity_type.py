# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class AmenityType(models.Model):
    _name = "amenity.type"
    _description = "Amenity Type"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
