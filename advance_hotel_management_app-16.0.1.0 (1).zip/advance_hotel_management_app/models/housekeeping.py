# -*- coding: utf-8 -*-
from datetime import datetime

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class HouseKeeping(models.Model):
    _name = "housekeeping.service"
    _description = "HouseKeeping"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Number', copy=False)
    start_date = fields.Date(string='Start Date', tracking=True)
    end_date = fields.Date(string='End Date', tracking=True)
    is_room = fields.Boolean(string="Room")
    room_id = fields.Many2one('hotel.room', string='Room', tracking=True)
    is_hall = fields.Boolean(string="Hall")
    hall_id = fields.Many2one('hall.hall', string='Hall', tracking=True)
    employee_ids = fields.Many2many('hr.employee', 'rela_housekeeping_employee', 'housekeeping_id', 'employee_id',
                                    string='Housekeeper', tracking=True)
    keeper_activity = fields.Text(string="Housekeeping Activity")
    state = fields.Selection([('assign', 'Assign'), ('process', 'Process'), ('done', 'Done')], default='assign',
                             tracking=True)

    @api.constrains('start_date', 'end_date')
    def _check_start_date_end_date(self):
        for rec in self:
            if rec.start_date and rec.end_date:
                if rec.start_date > rec.end_date:
                    raise ValidationError("End date should be greater than start date")

    def action_done(self):
        for rec in self:
            rec.state = 'done'

    def action_process(self):
        for rec in self:
            rec.state = 'process'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('housekeeping.service') or 'New'
        return super(HouseKeeping, self).create(vals)
