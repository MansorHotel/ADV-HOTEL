# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class HallHall(models.Model):
    _name = "hall.hall"
    _description = "Hall"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
    price = fields.Float(string="Price/Hours")
    note = fields.Text(string='Note')
    state = fields.Selection([('free', 'Free'), ('booked', 'Booked')], default='free', tracking=True)

    @api.constrains('price')
    def _check_price_greater_then_0(self):
        if self.price <= 0:
            raise ValidationError(_('Price should be greater then 0.'))
