# -*- coding: utf-8 -*-
from datetime import datetime

from dateutil import relativedelta
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class RoomBooking(models.Model):
    _name = "room.booking"
    _description = "Room Booking"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
    partner_id = fields.Many2one('res.partner', string="Customer", domain=[('is_customer', '=', True)],
                                 context={'default_is_customer': True})
    inquiry_id = fields.Many2one('booking.inquiry', string="Inquiry")

    no_of_room = fields.Integer(string='No of Room', compute='compute_payable_amount')
    adult = fields.Integer(string='Adult')
    child = fields.Integer(string='Child')
    alter_email = fields.Char(string="Alternative Email")
    alter_phone = fields.Char(string="Alternative Phone")
    room_charge = fields.Float(string="Room Charge", compute='compute_payable_amount')
    transport_charge = fields.Float(string="Transport Charge", compute='compute_payable_amount')
    amenity_charge = fields.Float(string="Amenity Charge", compute='compute_payable_amount')
    laundry_charge = fields.Float(string="Laundry Charge", compute='compute_payable_amount')
    restaurant_charge = fields.Float(string="Restaurant Charge", compute='compute_payable_amount')
    bar_charge = fields.Float(string="Bar Charge", compute='compute_payable_amount')
    extra_charge = fields.Float(string="Extra Charge", compute='compute_payable_amount')
    total_payable_amount = fields.Float(string="Total Payable Amount", compute='compute_payable_amount')
    invoice_amount = fields.Float(string="Invoiceable Amount", compute='compute_payable_amount')
    state = fields.Selection(
        [('draft', 'Draft'), ('confirm', 'Confirm'), ('in', 'Checkin'), ('out', 'Checkout'), ('cancel', 'Cancel')],
        string='State', tracking=True, default='draft')
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)
    room_line_ids = fields.One2many('room.booking.line', 'booking_id', string='Room')
    proof_ids = fields.One2many('proof.detail', 'booking_id', string='Proof')
    transport_ids = fields.One2many('transport.service', 'booking_id', string='Transport Service')
    booking_amenity_ids = fields.One2many('booking.amenity', 'booking_id', string='Amenity')
    laundry_ids = fields.One2many('hotel.laundry', 'booking_id', string='Laundry')
    restaurant_ids = fields.One2many('room.restaurant', 'booking_id', string='Order')
    bar_service_ids = fields.One2many('bar.service', 'booking_id', string='Bar')
    extra_service_ids = fields.One2many('extra.service', 'booking_id', string='Extra Service')
    deposit_amount = fields.Float(string='Deposit Amount')
    any_agent = fields.Boolean(string='Any Agent')
    agent_id = fields.Many2one('res.partner', string='Agent', domain="[('is_agent', '=', True)]",
                               context={'default_is_agent': True})
    commission_type = fields.Selection([('fix', 'Fix'), ('per', 'Percentage')], default='fix', tracking=True,
                                       string='Commission Type')
    commission = fields.Float(string='Commission')
    commission_amount = fields.Float(string='Commission Amount', compute="compute_commission_amount")
    commission_bill_id = fields.Many2one('account.move', string='Bill', copy=False)
    bill_payment_state = fields.Selection(related='invoice_id.payment_state', string="Bill Payment Status")
    invoice_id = fields.Many2one('account.move', string='Invoice', copy=False)
    payment_state = fields.Selection(related='invoice_id.payment_state', string="Payment Status")

    @api.depends('any_agent', 'agent_id', 'commission_type', 'commission')
    def compute_commission_amount(self):
        for rec in self:
            if rec.any_agent:
                if rec.commission_type == 'fix':
                    rec.commission_amount = rec.commission
                elif rec.commission_type == 'per':
                    if rec.total_payable_amount > 0 and rec.commission > 0:
                        rec.commission_amount = rec.total_payable_amount * rec.commission / 100
                    else:
                        rec.commission_amount = 0
                else:
                    rec.commission_amount = 0
            else:
                rec.commission_amount = 0

    def action_create_commission_bill(self):
        invoice_vals = self._prepare_bill()
        account_move = self.env['account.move'].create(invoice_vals)

        if account_move:
            self.commission_bill_id = account_move
        form_id = self.env.ref('account.view_move_form').id
        return {'type': 'ir.actions.act_window',
                'name': _('Bill'),
                'res_model': 'account.move',
                'view_mode': 'form',
                'views': [(form_id, 'form')],
                'domain': [('id', '=', account_move.id)],
                'res_id': account_move.id
                }

    def _prepare_bill(self):
        """
        Prepare the dict of values to create the new invoice for a sales order. This method may be
        overridden to implement custom invoice generation (making sure to call super() to establish
        a clean extension chain).
        """
        company_id = self.company_id
        self.ensure_one()
        name = 'Agent Commission for ' + self.name
        partner_id = self.agent_id
        invoice_lines = []
        vals = {
            'name': name,
            'price_unit': self.commission_amount,
            'quantity': 1,
        }
        invoice_lines.append((0, 0, vals))

        invoice_vals = {
            'move_type': 'in_invoice',
            'invoice_user_id': self.env.user.id,
            'partner_id': partner_id.id,
            'invoice_origin': self.name,
            'invoice_line_ids': invoice_lines,
            'invoice_date': fields.Datetime.now(),
            'company_id': company_id.id,
        }
        return invoice_vals

    @api.depends('deposit_amount', 'extra_service_ids', 'bar_service_ids', 'room_line_ids', 'laundry_ids',
                 'transport_ids', 'booking_amenity_ids', 'restaurant_ids')
    def compute_payable_amount(self):
        for rec in self:
            rec.room_charge = sum([x.total_charge for x in rec.room_line_ids])
            rec.transport_charge = sum([x.total_charge for x in rec.transport_ids])
            rec.amenity_charge = sum([x.price for x in rec.booking_amenity_ids])
            rec.laundry_charge = sum([x.total_charge for x in rec.laundry_ids])
            rec.restaurant_charge = sum([x.total_charge for x in rec.restaurant_ids])
            rec.extra_charge = sum([x.total_charge for x in rec.extra_service_ids])
            rec.bar_charge = sum([x.total_charge for x in rec.bar_service_ids])
            rec.no_of_room = len(rec.room_line_ids)
            rec.total_payable_amount = rec.extra_charge + rec.bar_charge + rec.room_charge + rec.transport_charge + rec.amenity_charge + rec.laundry_charge + rec.restaurant_charge
            rec.invoice_amount = rec.extra_charge + rec.bar_charge + rec.room_charge + rec.transport_charge + rec.amenity_charge + rec.laundry_charge + rec.restaurant_charge - rec.deposit_amount

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_confirm(self):
        for rec in self:
            rec.state = 'confirm'

    def action_checkin(self):
        for rec in self:
            rec.state = 'in'
            for line_id in rec.room_line_ids:
                line_id.room_id.state = 'booked'
            template_id = self.env.ref('advance_hotel_management_app.email_template_room_booking')
            if template_id:
                template = self.env['mail.template'].browse(template_id.id)
                template.subject = rec.company_id.name + ' Room Checkin (Ref ' + rec.name + ' )'
                template.body_html = 'Dear ' + rec.partner_id.name + '<br/>' + 'Here is your room booking ref <strong> ' + rec.name + '</strong> is confirm and checkin<br/>' + 'Your booking details is attached, please check it,<br/>' + 'If you have any query about booking please contact us.<br/> Best Wishes <br/>'
                if rec.user_id.signature:
                    template.body_html += rec.user_id.signature
                else:
                    template.body_html += rec.user_id.name
                template.sudo().send_mail(rec.id, force_send=True)

    def action_checkout(self):
        for rec in self:
            for laundry_id in rec.laundry_ids:
                if laundry_id.state in ['request', 'process']:
                    raise ValidationError('Some laundry is request or process stage, please complete')
            invoice_vals = self._prepare_invoice()
            account_move = self.env['account.move'].create(invoice_vals)

            if account_move:
                self.invoice_id = account_move
                rec.state = 'out'
                for line_id in rec.room_line_ids:
                    line_id.room_id.state = 'free'
                domain = [('reconciled', '=', False)]
                account_move.action_post()
                lines = self.invoice_id.line_ids
                for payment in self.inquiry_id.payment_ids:
                    # if payment.allocate:
                    payment_lines = payment.payment_id.line_ids.filtered_domain(domain)
                    for account in payment_lines.account_id:
                        (payment_lines + lines) \
                            .filtered_domain([('account_id', '=', account.id), ('reconciled', '=', False)]) \
                            .reconcile()
                template_id = self.env.ref('advance_hotel_management_app.email_template_room_booking')
                if template_id:
                    template = self.env['mail.template'].browse(template_id.id)
                    template.subject = rec.company_id.name + ' Room Checkout (Ref ' + rec.name + ' )'
                    template.body_html = 'Dear ' + rec.partner_id.name + '<br/>' + 'Here is your room booking ref <strong> ' + rec.name + '</strong> is checkout<br/>' + 'Thank you for staying in our hotel <br/>' + 'Your booking details is attached, please check it,<br/>' + 'If you have any query about booking please contact us.<br/> Best Wishes <br/>'
                    if rec.user_id.signature:
                        template.body_html += rec.user_id.signature
                    else:
                        template.body_html += rec.user_id.name
                    template.sudo().send_mail(rec.id, force_send=True)
            form_id = self.env.ref('account.view_move_form').id
            return {'type': 'ir.actions.act_window',
                    'name': _('Invoice'),
                    'res_model': 'account.move',
                    'view_mode': 'form',
                    'views': [(form_id, 'form')],
                    'domain': [('id', '=', account_move.id)],
                    'res_id': account_move.id
                    }

    def _prepare_invoice(self):
        """
        Prepare the dict of values to create the new invoice for a sales order. This method may be
        overridden to implement custom invoice generation (making sure to call super() to establish
        a clean extension chain).
        """
        company_id = self.env.user.company_id
        self.ensure_one()

        partner_id = self.partner_id
        invoice_lines = []
        if self.room_charge > 0:
            vals = {
                'name': 'Room Charge',
                'price_unit': self.room_charge,
                'quantity': 1,
            }
            invoice_lines.append((0, 0, vals))

        if self.restaurant_charge > 0:
            vals = {
                'name': 'Restaurant Charge',
                'price_unit': self.restaurant_charge,
                'quantity': 1,
            }
            invoice_lines.append((0, 0, vals))

        if self.laundry_charge > 0:
            vals = {
                'name': 'Laundry Charge',
                'price_unit': self.laundry_charge,
                'quantity': 1,
            }
            invoice_lines.append((0, 0, vals))

        if self.transport_charge > 0:
            vals = {
                'name': 'Transport Charge',
                'price_unit': self.transport_charge,
                'quantity': 1,
            }
            invoice_lines.append((0, 0, vals))

        if self.amenity_charge > 0:
            vals = {
                'name': 'Amenity Charge',
                'price_unit': self.amenity_charge,
                'quantity': 1,
            }
            invoice_lines.append((0, 0, vals))
        if self.bar_charge > 0:
            vals = {
                'name': 'Bar Charge',
                'price_unit': self.bar_charge,
                'quantity': 1,
            }
            invoice_lines.append((0, 0, vals))
        if self.extra_charge > 0:
            vals = {
                'name': 'Extra Charge',
                'price_unit': self.extra_charge,
                'quantity': 1,
            }
            invoice_lines.append((0, 0, vals))
        # if self.deposit_amount > 0:
        #     vals = {
        #         'name': 'Deposit Charge',
        #         'price_unit': - self.deposit_amount,
        #         'quantity': 1,
        #     }
        #     invoice_lines.append((0, 0, vals))

        invoice_vals = {
            'move_type': 'out_invoice',
            'invoice_user_id': self.env.user.id,
            'partner_id': partner_id.id,
            'invoice_origin': self.name,
            'invoice_line_ids': invoice_lines,
            'company_id': company_id.id,
        }
        return invoice_vals

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('room.booking') or _('New')
        result = super(RoomBooking, self).create(vals)
        return result


class RoomBookingLine(models.Model):
    _name = "room.booking.line"
    _description = "Room Booking Line"
    _rec_name = 'room_id'

    booking_id = fields.Many2one('room.booking', string="Booking")
    partner_id = fields.Many2one('res.partner', string="Customer", related='booking_id.partner_id')
    checkin_date = fields.Datetime(string='Checkin Date')
    checkout_date = fields.Datetime(string='Checkout Date')
    room_id = fields.Many2one('hotel.room', string="Room No")
    capacity = fields.Integer(string="Capacity")
    no_of_day = fields.Integer(string="No of Day", compute="compute_total_charge")
    room_facility_ids = fields.Many2many('room.facility', 'rel_room_booking_room_facility', 'booking_id',
                                         'room_facility_id', string='Room Facility')
    price = fields.Float(string="Price", required=1)
    total_charge = fields.Float(string="Total Charge", compute="compute_total_charge")
    uom_id = fields.Many2one('uom.uom', string='UOM')
    state = fields.Selection(
        [('free', 'Free'), ('book', 'Booked')], string='State', tracking=True, default='free', readonly=1)
    line_ids = fields.One2many('date.wise.room.booking', 'room_booking_line_id', string="Date wise Room")
    booking_state = fields.Selection(
        [('draft', 'Draft'), ('confirm', 'Confirm'), ('in', 'Checkin'), ('out', 'Checkout'), ('cancel', 'cancel')],
        string='State', related='booking_id.state', default='draft')

    @api.depends('room_id', 'price', 'checkin_date', 'checkout_date')
    def compute_total_charge(self):
        for rec in self:
            no_of_day = 0
            if rec.checkout_date and rec.checkin_date:
                different_date = rec.checkout_date - rec.checkin_date
                no_of_day = different_date.days + 1
            rec.no_of_day = no_of_day
            rec.total_charge = rec.price * no_of_day

    @api.onchange('room_id')
    def onchange_room_id(self):
        for rec in self:
            rec.price = rec.room_id.price
            rec.uom_id = rec.room_id.uom_id
            rec.room_facility_ids = rec.room_id.room_facility_ids
            rec.capacity = rec.room_id.capacity

    @api.constrains('checkin_date', 'checkout_date')
    def _check_checkin_date_checkout_date(self):
        for rec in self:
            if rec.checkin_date and rec.checkout_date:
                if rec.checkin_date > rec.checkout_date:
                    raise ValidationError("Checkout Date Must be Greater Then Checkin Date")

    @api.onchange('checkin_date', 'checkout_date')
    def onchange_and_take_line_data(self):
        for rec in self:
            print('jjjjjjj')
            rec.line_ids = False
            if rec.checkin_date and rec.checkout_date:
                fmt = '%Y-%m-%d %H:%M:%S'
                d1 = datetime.strptime(str(rec.checkin_date), fmt)
                d2 = datetime.strptime(str(rec.checkout_date), fmt)
                dates_btwn = d1 - relativedelta.relativedelta(days=1)
                line_vals = []
                while dates_btwn < d2:
                    # if dates_btwn.month == self.month_date.month:
                    print("dates_between=========>>>", dates_btwn.date())
                    dates_btwn = dates_btwn + relativedelta.relativedelta(days=1)
                    vals = {
                        'room_id': rec.room_id.id,
                        'date': dates_btwn,
                    }
                    line_vals.append((0, 0, vals))
                rec.line_ids = line_vals


class DateWiseRoomBooking(models.Model):
    _name = "date.wise.room.booking"
    _description = "Date Wise Room Booking"
    _rec_name = 'room_id'

    room_booking_line_id = fields.Many2one('room.booking.line', string="Room Line")
    date = fields.Date(string='Date')
    room_id = fields.Many2one('hotel.room', string="Room No")


class ProofDetail(models.Model):
    _name = "proof.detail"
    _description = "Proof Detail"
    _rec_name = 'name'

    booking_id = fields.Many2one('room.booking', string="Booking")
    customer_name = fields.Char(string="Full Name")
    name = fields.Char(string="Document Name")
    number = fields.Char(string="Document Number")
    document = fields.Binary(string="Document")


class BookingAmenity(models.Model):
    _name = "booking.amenity"
    _description = "Booking Amenity"
    _rec_name = 'amenity_id'

    booking_id = fields.Many2one('room.booking', string="Booking")
    amenity_id = fields.Many2one('amenity.amenity', string="Amenity")
    amenity_type_id = fields.Many2one('amenity.type', string="Amenity Type")
    price = fields.Float(string="Price")

    @api.onchange('amenity_id')
    def onchange_amenity_id(self):
        for rec in self:
            rec.amenity_type_id = rec.amenity_id.amenity_type_id


class BarService(models.Model):
    _name = "bar.service"
    _description = "Bar Detail"
    _rec_name = 'name'

    name = fields.Char(string="Name")
    booking_id = fields.Many2one('room.booking', string="Booking")
    partner_id = fields.Many2one('res.partner', string="Customer", related='booking_id.partner_id')

    bar_id = fields.Many2one('bar.menu', string="Product")
    quantity = fields.Float(string="Quantity")
    price = fields.Float(string="Price")
    uom_id = fields.Many2one('uom.uom', string='UOM')
    total_charge = fields.Float(string="Total Charge", compute="compute_total_charge")
    note = fields.Text(string='Description')

    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)

    @api.onchange('bar_id')
    def onchange_bar_id(self):
        for rec in self:
            rec.price = rec.bar_id.price
            rec.uom_id = rec.bar_id.uom_id
            rec.note = rec.bar_id.note

    @api.depends('price', 'quantity')
    def compute_total_charge(self):
        for rec in self:
            rec.total_charge = rec.price * rec.quantity

    @api.constrains('quantity', 'price')
    def _check_some_validation(self):
        for rec in self:
            if rec.quantity <= 0:
                raise ValidationError(_('Bar Quantity should be greater then 0.'))
            if rec.price <= 0:
                raise ValidationError(_('Bar charge should be greater then 0.'))

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('bar.service') or _('New')
        result = super(BarService, self).create(vals)
        return result


class ExtraService(models.Model):
    _name = "extra.service"
    _description = "Extra Service"
    _rec_name = 'name'

    name = fields.Char(string="Name")
    booking_id = fields.Many2one('room.booking', string="Booking")
    quantity = fields.Float(string="Quantity")
    price = fields.Float(string="Price")
    total_charge = fields.Float(string="Total Charge", compute="compute_total_charge")

    @api.depends('price', 'quantity')
    def compute_total_charge(self):
        for rec in self:
            rec.total_charge = rec.price * rec.quantity

    @api.constrains('quantity', 'price')
    def _check_some_validation(self):
        for rec in self:
            if rec.quantity <= 0:
                raise ValidationError(_('Bar Quantity should be greater then 0.'))
            if rec.price <= 0:
                raise ValidationError(_('Bar charge should be greater then 0.'))
