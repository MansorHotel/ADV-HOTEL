# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class BarMenu(models.Model):
    _name = "bar.menu"
    _description = "Bar Menu"
    _rec_name = 'product_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Sequence', tracking=True)
    product_id = fields.Many2one('product.product', string='Product Name', domain=[('is_bar', '=', True)],
                                 context={'default_is_bar': True})
    note = fields.Char(string='Description')
    price = fields.Float(string="Price")
    uom_id = fields.Many2one('uom.uom', string='UOM')

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('bar.menu') or _('New')
        result = super(BarMenu, self).create(vals)
        return result

    @api.onchange('product_id')
    def onchange_product_id(self):
        for rec in self:
            rec.price = rec.product_id.lst_price
            rec.uom_id = rec.product_id.uom_id

    @api.constrains('price')
    def _check_price_greater_then_0(self):
        if self.price <= 0:
            raise ValidationError(_('Price should be greater then 0.'))
