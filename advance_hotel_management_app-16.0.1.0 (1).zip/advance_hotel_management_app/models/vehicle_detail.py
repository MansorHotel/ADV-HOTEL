# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class VehicleDetail(models.Model):
    _name = "vehicle.detail"
    _description = "Vehicle Detail"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Vehicle Name', tracking=True)
    sequence = fields.Char(string='Sequence', tracking=True)
    vehicle_number_id = fields.Char(string='Vehicle Number', tracking=True)
    vehicle_type_id = fields.Many2one('vehicle.type', string='Vehicle Type')
    capacity = fields.Integer(string="Capacity")
    price = fields.Float(string="Price")
    uom_id = fields.Many2one('uom.uom', string='UOM')

    @api.model
    def create(self, vals):
        vals['sequence'] = self.env['ir.sequence'].next_by_code('vehicle.detail') or _('New')
        result = super(VehicleDetail, self).create(vals)
        return result

    @api.constrains('price')
    def _check_price_greater_then_0(self):
        if self.price <= 0:
            raise ValidationError(_('Price should be greater then 0.'))
