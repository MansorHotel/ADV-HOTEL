# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class TransportService(models.Model):
    _name = "transport.service"
    _description = "Transport Service"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    booking_id = fields.Many2one('room.booking', string="Booking")
    name = fields.Char(string='Name', tracking=True)
    partner_id = fields.Many2one('res.partner', string="Customer", related='booking_id.partner_id')

    vehicle_id = fields.Many2one('vehicle.detail', string="Vehicle")
    price = fields.Float(string="Price")
    uom_id = fields.Many2one('uom.uom', string='UOM')
    total_km = fields.Float(string="Total Km")
    total_charge = fields.Float(string="Total Charge", compute="compute_total_charge")
    transport_type = fields.Selection([('pickup', 'Pickup'), ('drop', 'Drop')], string='Transport Type', tracking=True,
                                      default='pickup')
    start_date = fields.Datetime(string='Start Time')
    driver_id = fields.Many2one('res.partner', string="Driver", domain=[('is_driver', '=', True)],
                                context={'default_is_driver': True})
    street = fields.Char(string="Street")
    street2 = fields.Char(string="Street2")
    city = fields.Char(string="City")
    state = fields.Selection([('pending', 'Pending'), ('complete', 'Complete'), ('cancel', 'Cancel')], string='State',
                             tracking=True, default='pending')
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)

    @api.onchange('vehicle_id')
    def onchange_vehicle_id(self):
        for rec in self:
            rec.price = rec.vehicle_id.price
            rec.uom_id = rec.vehicle_id.uom_id

    @api.depends('price', 'total_km')
    def compute_total_charge(self):
        for rec in self:
            rec.total_charge = rec.price * rec.total_km

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_complete(self):
        for rec in self:
            rec.state = 'complete'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('transport.service') or _('New')
        result = super(TransportService, self).create(vals)
        return result

    @api.constrains('total_km', 'price')
    def _check_parent_id(self):
        if self.total_km <= 0:
            raise ValidationError(_('Transport KM should be greater then 0.'))
        if self.price <= 0:
            raise ValidationError(_('Transport charge should be greater then 0.'))
