# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class RoomType(models.Model):
    _name = "room.type"
    _description = "Room Type"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
