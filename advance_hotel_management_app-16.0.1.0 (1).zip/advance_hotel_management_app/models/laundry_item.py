# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class LaundryItem(models.Model):
    _name = "laundry.item"
    _description = "Vehicle Item"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Service Name', tracking=True)

