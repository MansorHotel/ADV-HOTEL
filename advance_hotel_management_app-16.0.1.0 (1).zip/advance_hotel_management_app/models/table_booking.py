# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class TableBooking(models.Model):
    _name = "table.booking"
    _description = "Table Booking"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
    partner_id = fields.Many2one('res.partner', string="Customer", domain=[('is_customer', '=', True)],
                                 context={'default_is_customer': True})
    inquiry_id = fields.Many2one('booking.inquiry', string="Inquiry")
    start_date = fields.Datetime(string='Start Date')
    end_date = fields.Datetime(string='Departure Date')
    hotel_guest = fields.Boolean(string='Hotel Guest')
    state = fields.Selection(
        [('draft', 'Draft'), ('confirm', 'Confirm'), ('complete', 'Complete'), ('cancel', 'Cancel')],
        string='State', tracking=True, default='draft')
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)
    table_number_ids = fields.Many2many('table.number', 'relation_order_table_number', 'table_booking_id',
                                        'table_number_id', string='Table Details')
    order_count = fields.Integer(string="Order Count", compute="compute_order")

    def compute_order(self):
        for rec in self:
            order_ids = rec.env['table.order'].search([('table_booking_id', '=', rec.id)])
            rec.order_count = len(order_ids)

    def action_table_order(self):
        xml_id = 'advance_hotel_management_app.table_order_tree_view'
        tree_view_id = self.env.ref(xml_id).id
        xml_id = 'advance_hotel_management_app.table_order_form_view'
        form_view_id = self.env.ref(xml_id).id
        return {
            'name': _('Order'),
            'view_type': 'form',
            'view_mode': 'tree',
            'views': [(tree_view_id, 'tree'),
                      (form_view_id, 'form')],
            'res_model': 'table.order',
            'domain': [('table_booking_id', '=', self.id)],
            'context': {'create': 0},
            'type': 'ir.actions.act_window',
        }

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_confirm(self):
        for rec in self:
            rec.state = 'confirm'
            for line_id in rec.table_number_ids:
                line_id.state = 'book'

    def action_complete(self):
        for rec in self:
            rec.state = 'complete'
            for line_id in rec.table_number_ids:
                line_id.state = 'free'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('table.booking') or _('New')
        result = super(TableBooking, self).create(vals)
        return result

    @api.constrains('start_date', 'end_date')
    def _check_registration(self):
        for rec in self:
            if rec.start_date and rec.end_date:
                if rec.start_date > rec.end_date:
                    raise ValidationError("Date End Must be Greater Then Date Start")

    def action_create_order(self):
        order_id = self.env['table.order'].create({
            'table_booking_id': self.id or False,
            'partner_id': self.partner_id.id or False,
            'company_id': self.company_id.id or False,
            'date': self.start_date,
            'hotel_guest': self.hotel_guest,
            'user_id': self.user_id.id,
            'table_number_ids': [(6, 0, self.table_number_ids.ids)],
        })
        form_id = self.env.ref('advance_hotel_management_app.table_order_form_view').id
        return {'type': 'ir.actions.act_window',
                'name': _('Order'),
                'res_model': 'table.order',
                'view_mode': 'form',
                'views': [(form_id, 'form')],
                'domain': [('id', '=', order_id.id)],
                'res_id': order_id.id
                }


class TableNumber(models.Model):
    _name = "table.number"
    _description = "Table Number"
    _rec_name = 'name'

    name = fields.Char(string='Sequence', tracking=True)
    number = fields.Char(string="Table Number")
    capacity = fields.Integer(string="Capacity")
    state = fields.Selection(
        [('free', 'Free'), ('book', 'Booked')], string='State', tracking=True, default='free', readonly=1)

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('table.number') or _('New')
        result = super(TableNumber, self).create(vals)
        return result


class TableOrder(models.Model):
    _name = "table.order"
    _description = "Table Order"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    table_booking_id = fields.Many2one('table.booking', string="Table Booking")
    name = fields.Char(string='Name', tracking=True)
    partner_id = fields.Many2one('res.partner', string="Customer", domain=[('is_customer', '=', True)],
                                 context={'default_is_customer': True})
    date = fields.Datetime(string='Date')
    hotel_guest = fields.Boolean(string='Hotel Guest')
    state = fields.Selection(
        [('draft', 'Draft'), ('Order', 'Order'), ('Invoice', 'Invoice'), ('Done', 'Done')],
        string='State', tracking=True, default='draft')
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)
    employee_id = fields.Many2one('hr.employee', string='Waiter')
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)
    table_number_ids = fields.Many2many('table.number', 'relation_table_order_table_number', 'table_booking_id',
                                        'table_number_id', string='Table Details')
    order_list_ids = fields.One2many('table.order.list', 'table_order_id', string="Order List")

    kot_count = fields.Integer(string="Order Count", compute="compute_order")

    invoice_count = fields.Integer(string="Invoice Count", compute="compute_order")

    def action_done(self):
        for rec in self:
            for line_id in rec.order_list_ids:
                if not line_id.is_invoice:
                    raise ValidationError("Some order list invoice is not created... please create invoice after done process")
            for table in rec.table_number_ids:
                table.state = 'free'
            rec.state = 'Done'

    def action_view_invoice(self):
        xml_id = 'account.view_invoice_tree'
        tree_view_id = self.env.ref(xml_id).id
        xml_id = 'account.view_move_form'
        form_view_id = self.env.ref(xml_id).id
        return {
            'name': _('Invoice'),
            'view_type': 'form',
            'view_mode': 'tree',
            'views': [(tree_view_id, 'tree'),
                      (form_view_id, 'form')],
            'res_model': 'account.move',
            'domain': [('invoice_origin', '=', self.name), ('move_type', '=', 'out_invoice')],
            'context': {'create': 0, 'delete': 0},
            'type': 'ir.actions.act_window',
        }
    def action_create_invoice(self):
        invoice_vals = self._prepare_invoice()
        account_move = self.env['account.move'].create(invoice_vals)

        if account_move:
            self.state = 'Invoice'
        form_id = self.env.ref('account.view_move_form').id
        return {'type': 'ir.actions.act_window',
                'name': _('Invoice'),
                'res_model': 'account.move',
                'view_mode': 'form',
                'views': [(form_id, 'form')],
                'domain': [('id', '=', account_move.id)],
                'res_id': account_move.id
                }

    def _prepare_invoice(self):
        """
        Prepare the dict of values to create the new invoice for a sales order. This method may be
        overridden to implement custom invoice generation (making sure to call super() to establish
        a clean extension chain).
        """
        company_id = self.env.user.company_id
        self.ensure_one()

        name = self.name
        # account_id = self.partner_id.property_account_receivable_id

        partner_id = self.partner_id
        invoice_lines = []
        for line_id in self.order_list_ids:
            if not line_id.is_invoice:
                vals = {
                    'product_id': line_id.food_id.product_id.id,
                    'name': line_id.food_id.product_id.name,
                    'price_unit': line_id.price,
                    'quantity': line_id.quantity,
                }
                line_id.is_invoice = True
                invoice_lines.append((0, 0, vals))
        if invoice_lines:
            invoice_vals = {
                'move_type': 'out_invoice',
                'invoice_user_id': self.env.user.id,
                'partner_id': partner_id.id,
                'invoice_origin': self.name,
                'invoice_line_ids': invoice_lines,
                'company_id': company_id.id,
            }
            return invoice_vals
        else:
            raise ValidationError("There are not invoice line... all food invoice already create, please select other food")

    def compute_order(self):
        for rec in self:
            kot_ids = rec.env['order.kot'].search([('table_order_id', '=', rec.id)])
            rec.kot_count = len(kot_ids)
            invoice_ids = rec.env['account.move'].search([('invoice_origin', '=', self.name), ('move_type', '=', 'out_invoice')])
            rec.invoice_count = len(invoice_ids)

    def action_view_kot(self):
        xml_id = 'advance_hotel_management_app.order_kot_tree_view'
        tree_view_id = self.env.ref(xml_id).id
        xml_id = 'advance_hotel_management_app.order_kot_form_view'
        form_view_id = self.env.ref(xml_id).id
        return {
            'name': _('KOT'),
            'view_type': 'form',
            'view_mode': 'tree',
            'views': [(tree_view_id, 'tree'),
                      (form_view_id, 'form')],
            'res_model': 'order.kot',
            'domain': [('table_order_id', '=', self.id)],
            'context': {'create': 0},
            'type': 'ir.actions.act_window',
        }

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('table.order') or _('New')
        result = super(TableOrder, self).create(vals)
        return result

    def action_create_kot(self):
        order_list_vals = []
        for line_id in self.order_list_ids:
            vals = {
                'food_id': line_id.food_id.id,
                'quantity': line_id.quantity,
            }
            line_id.kot = True
            order_list_vals.append((0, 0, vals))
        kot_id = self.env['order.kot'].create({
            'table_booking_id': self.table_booking_id.id or False,
            'table_order_id': self.id or False,
            'company_id': self.company_id.id or False,
            'employee_id': self.employee_id.id or False,
            'date': self.date,
            'user_id': self.user_id.id,
            'table_number_ids': [(6, 0, self.table_number_ids.ids)],
            'order_list_ids': order_list_vals,
        })
        self.state = 'Order'
        for line_id in self.table_number_ids:
            line_id.state = 'book'
        form_id = self.env.ref('advance_hotel_management_app.order_kot_form_view').id
        return {'type': 'ir.actions.act_window',
                'name': _('KOT'),
                'res_model': 'order.kot',
                'view_mode': 'form',
                'views': [(form_id, 'form')],
                'domain': [('id', '=', kot_id.id)],
                'res_id': kot_id.id
                }

    def action_update_kot(self):
        order_list_vals = []
        for line_id in self.order_list_ids:
            if not line_id.kot:
                vals = {
                    'food_id': line_id.food_id.id,
                    'quantity': line_id.quantity,
                }
                line_id.kot = True
                order_list_vals.append((0, 0, vals))
        if order_list_vals:
            kot_id = self.env['order.kot'].create({
                'table_booking_id': self.table_booking_id.id or False,
                'table_order_id': self.id or False,
                'company_id': self.company_id.id or False,
                'employee_id': self.employee_id.id or False,
                'date': self.date,
                'user_id': self.user_id.id,
                'table_number_ids': [(6, 0, self.table_number_ids.ids)],
                'order_list_ids': order_list_vals,
            })
            form_id = self.env.ref('advance_hotel_management_app.order_kot_form_view').id
            return {'type': 'ir.actions.act_window',
                    'name': _('KOT'),
                    'res_model': 'order.kot',
                    'view_mode': 'form',
                    'views': [(form_id, 'form')],
                    'domain': [('id', '=', kot_id.id)],
                    'res_id': kot_id.id
                    }
        else:
            raise ValidationError('KOT already update.... please select other food for update')


class TableOrderList(models.Model):
    _name = "table.order.list"
    _description = "Table Order"
    _rec_name = 'food_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    table_order_id = fields.Many2one('table.order', string="Table Order")
    food_id = fields.Many2one('food.food', string="Food")
    quantity = fields.Float(string="Quantity")
    price = fields.Float(string="Price")
    subtotal = fields.Float(string="Subtotal", compute="compute_subtotal")
    is_invoice = fields.Boolean(string='Invoice')
    kot = fields.Boolean(string='KOT')

    @api.onchange('food_id')
    def onchange_food_id(self):
        for rec in self:
            rec.price = rec.food_id.price

    @api.depends('quantity', 'price')
    def compute_subtotal(self):
        for rec in self:
            rec.subtotal = rec.quantity * rec.price

    @api.constrains('quantity', 'price')
    def _check_some_validation(self):
        for rec in self:
            if rec.quantity <= 0:
                raise ValidationError(_('Order List Quantity should be greater then 0.'))
            if rec.price <= 0:
                raise ValidationError(_('Order List charge should be greater then 0.'))


class OrderKOT(models.Model):
    _name = "order.kot"
    _description = "KOT"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    table_booking_id = fields.Many2one('table.booking', string="Table Booking No")
    table_order_id = fields.Many2one('table.order', string="Table Order No")
    name = fields.Char(string='KOT No', tracking=True)
    date = fields.Datetime(string='Date')
    employee_id = fields.Many2one('hr.employee', string='Waiter')
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)
    table_number_ids = fields.Many2many('table.number', 'relation_order_kot_table_number', 'kot_id',
                                        'table_number_id', string='Table Details')
    order_list_ids = fields.One2many('kot.order.list', 'kot_id', string="Order List")

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('order.kot') or _('New')
        result = super(OrderKOT, self).create(vals)
        return result


class KOTOrderList(models.Model):
    _name = "kot.order.list"
    _description = "KOT Order"
    _rec_name = 'food_id'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    kot_id = fields.Many2one('order.kot', string="KOT")
    food_id = fields.Many2one('food.food', string="Food")
    quantity = fields.Float(string="Quantity")
