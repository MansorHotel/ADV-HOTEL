# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class VehicleType(models.Model):
    _name = "vehicle.type"
    _description = "Vehicle Type"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
