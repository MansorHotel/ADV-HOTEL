# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class HotelRoom(models.Model):
    _name = "hotel.room"
    _description = "Room"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
    image = fields.Binary(string='Image')
    floor_id = fields.Many2one('room.floor', string='Floor')
    room_category_id = fields.Many2one('room.category', string='Room Category')
    room_type_id = fields.Many2one('room.type', string='Room Type')
    room_facility_ids = fields.Many2many('room.facility', 'rel_room_room_facility', 'room_id', 'room_facility_id',
                                         string='Room Facility')
    capacity = fields.Integer(string="Capacity")
    price = fields.Float(string="Price", required=1)
    uom_id = fields.Many2one('uom.uom', string='UOM', required=1)
    state = fields.Selection([('free', 'Free'), ('booked', 'Booked')], default='free', tracking=True)

    @api.constrains('price')
    def _check_price_greater_then_0(self):
        if self.price <= 0:
            raise ValidationError(_('Price should be greater then 0.'))
