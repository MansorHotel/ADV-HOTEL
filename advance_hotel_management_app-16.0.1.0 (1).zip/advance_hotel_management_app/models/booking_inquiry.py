# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class BookingInquiry(models.Model):
    _name = "booking.inquiry"
    _description = "Booking Inquiry"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
    inquiry_name = fields.Char(string="Inquirer Name", tracking=True)
    partner_id = fields.Many2one('res.partner', string="Customer", domain=[('is_customer', '=', True)],
                                 context={'default_is_customer': True})
    phone = fields.Char(string="Inquirer Phone", tracking=True)
    email = fields.Char(string="Inquirer Email", tracking=True)
    inquiry_for = fields.Selection([('room', 'Room'), ('hall', 'Hall'), ('Restaurant', 'Restaurant')],
                                   string='Inquiry For', tracking=True, default='room')
    arrival_date = fields.Datetime(string='Arrival Date')
    departure_date = fields.Datetime(string='Departure Date', compute='compute_departure_date')
    booking_time = fields.Integer(string="Booking Time")
    type = fields.Char(string="Type")
    child = fields.Integer(string="Child")
    person = fields.Integer(string="Person")
    capacity = fields.Integer(string="Hall Capacity")
    no_of_room = fields.Integer(string="No of Room")
    note = fields.Html(string="Description")
    state = fields.Selection([('draft', 'Draft'), ('confirm', 'Confirm'), ('booking', 'Booking'), ('cancel', 'Cancel')],
                             string='State', tracking=True, default='draft')
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)
    payment_ids = fields.One2many('account.payment', 'inquiry_id', string='Payment')

    def action_create_payment(self):
        return {
            'name': 'Advance Payment',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            "view_type": "form",
            'res_model': 'advance.payment.wizard',
            'target': 'new',
            'view_id': self.env.ref('advance_hotel_management_app.advance_payment_wizard_form_view').id,
            'context': self._context,
        }

    def action_create_booking(self):
        return {
            'name': 'Booking',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            "view_type": "form",
            'res_model': 'create.booking.wizard',
            'target': 'new',
            'view_id': self.env.ref('advance_hotel_management_app.create_booking_wizard_form_view').id,
            'context': self._context,
        }

    @api.onchange('partner_id')
    def onchange_partner_id(self):
        for rec in self:
            rec.phone = rec.partner_id.phone
            rec.email = rec.partner_id.email
            rec.inquiry_name = rec.partner_id.name

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_send_mail(self):
        for rec in self:
            template_id = self.env.ref('advance_hotel_management_app.email_template_confirm_inquiry')
            if template_id:
                template = self.env['mail.template'].browse(template_id.id)
                template.subject = 'Inquiry Booking Confirmation'
                body_html = 'Dear ' + rec.inquiry_name + '<br /><br />' + 'Here is your booking ref <strong>' + self.name + '</strong> is confirm from <strong>' + str(
                    self.arrival_date) + '</strong> to <strong>' + str(
                    self.departure_date) + '</strong> <br /><br /> If you have any query about booking please contact us.<br />' + 'Best Wishes <br/>' + self.user_id.name + '(' + self.company_id.name + ')'
                template.body_html = body_html
                template.sudo().send_mail(self.id, force_send=True)

    def action_confirm(self):
        for rec in self:
            template_id = self.env.ref('advance_hotel_management_app.email_template_confirm_inquiry')
            if template_id:
                template = self.env['mail.template'].browse(template_id.id)
                template.subject = 'Inquiry Booking Confirmation'
                body_html = 'Dear ' + rec.inquiry_name + '<br /><br />' + 'Here is your booking ref <strong>' + self.name + '</strong> is confirm from <strong>' + str(
                    self.arrival_date) + '</strong> to <strong>' + str(
                    self.departure_date) + '</strong> <br /><br /> If you have any query about booking please contact us.<br />' + 'Best Wishes <br/>' + self.user_id.name + '(' + self.company_id.name + ')'
                template.body_html = body_html
                template.sudo().send_mail(rec.id, force_send=True)
            rec.state = 'confirm'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('booking.inquiry') or _('New')
        result = super(BookingInquiry, self).create(vals)
        return result

    @api.depends('arrival_date', 'booking_time', 'inquiry_for')
    def compute_departure_date(self):
        for rec in self:
            if rec.arrival_date and rec.booking_time > 0:
                if rec.inquiry_for == 'room':
                    rec.departure_date = rec.arrival_date + timedelta(days=rec.booking_time-1)
                else:
                    rec.departure_date = rec.arrival_date + timedelta(hours=rec.booking_time-1)
            else:
                rec.departure_date = False

    @api.constrains('booking_time')
    def _check_parent_id(self):
        if self.booking_time <= 0:
            raise ValidationError(_('Booking time should be greater then 0.'))


class AccountPaymentInherited(models.Model):
    _inherit = 'account.payment'

    inquiry_id = fields.Many2one('booking.inquiry', string="Booking Inquiry")
