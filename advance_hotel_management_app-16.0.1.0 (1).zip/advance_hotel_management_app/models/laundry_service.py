# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class LaundryService(models.Model):
    _name = "laundry.service"
    _description = "Laundry"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Service Name', tracking=True)
    price = fields.Float(string="Price")
    uom_id = fields.Many2one('uom.uom', string='UOM')

    @api.constrains('price')
    def _check_price_greater_then_0(self):
        if self.price <= 0:
            raise ValidationError(_('Price should be greater then 0.'))
