# -*- coding: utf-8 -*-
from datetime import timedelta

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class HotelLaundry(models.Model):
    _name = "hotel.laundry"
    _description = "Laundry Detail"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    booking_id = fields.Many2one('room.booking', string="Booking")
    name = fields.Char(string='Name', tracking=True)
    partner_id = fields.Many2one('res.partner', string="Customer", related='booking_id.partner_id')

    service_id = fields.Many2one('laundry.service', string="Service")
    laundry_item_ids = fields.Many2many('laundry.item', 'rel_laundry_details_item', 'laundry_id', 'laundry_item_id',
                                        string="Laundry Item")
    quantity = fields.Float(string="Quantity")
    price = fields.Float(string="Price")
    uom_id = fields.Many2one('uom.uom', string='UOM')
    total_charge = fields.Float(string="Total Charge", compute="compute_total_charge")
    deadline_date = fields.Datetime(string='Deadline')

    state = fields.Selection(
        [('request', 'Request'), ('process', 'Process'), ('complete', 'Complete'), ('cancel', 'Cancel')],
        string='State',
        tracking=True, default='request')
    user_id = fields.Many2one('res.users', default=lambda self: self.env.user)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id)

    @api.onchange('service_id')
    def onchange_service_id(self):
        for rec in self:
            rec.price = rec.service_id.price
            rec.uom_id = rec.service_id.uom_id

    @api.depends('price', 'quantity')
    def compute_total_charge(self):
        for rec in self:
            rec.total_charge = rec.price * rec.quantity

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_process(self):
        for rec in self:
            rec.state = 'process'

    def action_complete(self):
        for rec in self:
            rec.state = 'complete'

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('hotel.laundry') or _('New')
        result = super(HotelLaundry, self).create(vals)
        return result

    @api.constrains('quantity', 'price', 'deadline_date', 'create_date')
    def _check_some_validation(self):
        if self.quantity <= 0:
            raise ValidationError(_('Landry Quantity should be greater then 0.'))
        if self.price <= 0:
            raise ValidationError(_('Laundry charge should be greater then 0.'))
        if self.create_date and self.deadline_date:
            if self.create_date > self.deadline_date:
                raise ValidationError('Deadline date should be greater then create date')
