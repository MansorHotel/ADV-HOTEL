# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class RoomRestaurant(models.Model):
    _name = "room.restaurant"
    _description = "Order"
    _rec_name = 'room_id'

    name = fields.Char(string="Name")
    booking_id = fields.Many2one('room.booking', string="Booking")
    partner_id = fields.Many2one('res.partner',related='booking_id.partner_id', string="Customer")
    room_id = fields.Many2one('hotel.room', string="Room No")
    table_reservation = fields.Boolean(string="Table Reservation")
    total_charge = fields.Float(string="Payable Charge", compute="compute_total_charge")
    restaurant_food_ids = fields.One2many('room.restaurant.food', 'restaurant_id', 'Foods')

    @api.depends('restaurant_food_ids')
    def compute_total_charge(self):
        for rec in self:
            rec.total_charge = sum([x.total_charge for x in rec.restaurant_food_ids])

    @api.onchange('booking_id')
    def set_domain_room_id(self):
        for rec in self:
            room_vals = []
            for line_id in rec.booking_id.room_line_ids:
                room_vals.append(int(line_id.room_id.id))
            print(room_vals,'fffff')
            domain = {'domain': {'room_id': [("id", 'in', room_vals)]}}
            return domain

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('room.restaurant') or _('New')
        result = super(RoomRestaurant, self).create(vals)
        return result


class RoomRestaurantFood(models.Model):
    _name = "room.restaurant.food"
    _description = "Restaurant Food"
    _rec_name = 'food_id'

    restaurant_id = fields.Many2one('room.restaurant', string="Restaurant")
    food_id = fields.Many2one('food.food', string="Food", required=1)
    food_include = fields.Boolean(string="Food Include")
    quantity = fields.Float(string="Quantity", required=1)
    price = fields.Float(string="Price", required=1)
    uom_id = fields.Many2one('uom.uom', string='UOM')
    total_charge = fields.Float(string="Total Charge", compute="compute_total_charge")

    @api.onchange('food_id')
    def onchange_food_id(self):
        for rec in self:
            rec.price = rec.food_id.price
            rec.uom_id = rec.food_id.uom_id

    @api.depends('food_include', 'quantity', 'price')
    def compute_total_charge(self):
        for rec in self:
            if rec.food_include:
                rec.total_charge = 0
            else:
                rec.total_charge = rec.quantity * rec.price

    @api.constrains('quantity', 'price')
    def _check_price_greater_then_0(self):
        if self.price <= 0:
            raise ValidationError(_('Restaurant Food Price should be greater then 0.'))
        if self.quantity <= 0:
            raise ValidationError(_('Restaurant Food Quantity should be greater then 0.'))
