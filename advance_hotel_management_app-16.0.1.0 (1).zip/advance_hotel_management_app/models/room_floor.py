# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class Floor(models.Model):
    _name = "room.floor"
    _description = "Floor"
    _rec_name = 'floor_number'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Sequence', tracking=True)
    floor_number = fields.Char(string='Floor Number', tracking=True)
    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user)

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('room.floor') or _('New')
        result = super(Floor, self).create(vals)
        return result
