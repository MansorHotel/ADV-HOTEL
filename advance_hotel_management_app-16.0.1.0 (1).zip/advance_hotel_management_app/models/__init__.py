# -*- coding: utf-8 -*-

from . import room_facility
from . import room_category
from . import room_type
from . import room_floor
from . import room_status
from . import room
from . import vehicle_type
from . import vehicle_detail
from . import laundry_service
from . import laundry_item
from . import product_template_inherited
from . import bar_menu
from . import food_category
from . import food
from . import amenity_type
from . import amenity
from . import res_partner_inherited
from . import booking_inquiry
from . import hall
from . import hall_booking
from . import table_booking
from . import room_booking
from . import transport_service
from . import hotel_laundry
from . import room_restaurant
from . import housekeeping



