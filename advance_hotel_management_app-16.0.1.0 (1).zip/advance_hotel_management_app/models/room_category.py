# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class RoomCategory(models.Model):
    _name = "room.category"
    _description = "Hotel Category"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', tracking=True)
