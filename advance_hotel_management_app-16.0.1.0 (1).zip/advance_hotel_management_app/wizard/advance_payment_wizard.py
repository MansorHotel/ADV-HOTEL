from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class AdvancePaymentWizard(models.TransientModel):
    _name = 'advance.payment.wizard'
    _description = "Advance Payment Wizard"

    inquiry_id = fields.Many2one('booking.inquiry', string='Booking Inquiry')
    journal_id = fields.Many2one('account.journal', string="Payment Journal")
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.user.company_id.currency_id,
                                  string="Currency")
    ref = fields.Char(string="Ref")
    amount = fields.Float(string='Amount')

    @api.model
    def default_get(self, fields):
        res = super(AdvancePaymentWizard, self).default_get(fields)
        inquiry_id = self.env['booking.inquiry'].browse(self._context.get('active_id'))
        res['inquiry_id'] = inquiry_id.id
        return res

    def action_create_payment(self):
        if self.amount > 0:
            payment_vals = self._prepare_payment()
            payment_id = self.env['account.payment'].create(payment_vals)
            payment_id.action_post()
        else:
            raise ValidationError('Payment amount should be greater then 0')

    def _prepare_payment(self):

        payment_vals = {
            'currency_id': self.currency_id.id,
            'inquiry_id': self.inquiry_id.id,
            'payment_type': 'inbound',
            'partner_type': 'customer',
            'partner_id': self.inquiry_id.partner_id.id or False,
            'amount': self.amount,
            'journal_id': self.journal_id.id,
            'date': fields.Date.today(),
            'ref': self.ref,
        }
        return payment_vals
