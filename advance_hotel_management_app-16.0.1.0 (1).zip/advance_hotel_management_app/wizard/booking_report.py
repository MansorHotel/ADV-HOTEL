# -*- coding: utf-8 -*-


import base64
import calendar
from datetime import datetime

import xlsxwriter
from dateutil import relativedelta
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class BookingReport(models.TransientModel):
    _name = "booking.report.wizard"

    month_date = fields.Date(string="Month Date")
    report_type = fields.Selection([('per_day', 'Per Day Room Booked'), ('per_day_revenue', 'Revenue by Room Per Day')],
                                   default='per_day')
    file = fields.Binary()
    file_name = fields.Char(string="File Name")

    def print_excel_report(self):
        print('hello')
        month_last_date = self.month_date.replace(
            day=calendar.monthrange(self.month_date.year, self.month_date.month)[1])
        print('month_last_date', month_last_date)
        print(month_last_date.day)
        name_of_file = 'Booking Report.xls'
        file_path = 'Booking Report' + '.xls'
        workbook = xlsxwriter.Workbook('/tmp/' + file_path)
        align_left = workbook.add_format({'align': 'left'})
        align_right = workbook.add_format({'align': 'right'})
        align_right_green = workbook.add_format({'align': 'right', 'color': 'green'})
        align_right_red = workbook.add_format({'align': 'right', 'color': 'red'})
        align_left_red = workbook.add_format({'align': 'left', 'color': 'red'})
        align_left_green = workbook.add_format({'align': 'left', 'color': 'green'})
        merge_format = workbook.add_format({
            'bold': 1,
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#bcbabf', })

        cell_format = workbook.add_format({
            'bold': 1,
            'align': 'center',
        })
        cell_format1 = workbook.add_format({
            'bold': 0,
            'align': 'center',
            'fg_color': '#bcbabf'
        })
        title = "Booking Report"
        worksheet = workbook.add_worksheet('Booking Report')
        date_format = workbook.add_format({'num_format': 'dd/mm/yy'})

        worksheet.set_column(0, 0, 20)
        worksheet.set_column(0, 1, 23)
        worksheet.set_column(0, 2, 20)
        worksheet.set_column(0, 3, 15)
        worksheet.set_column(0, 4, 15)
        worksheet.set_column(0, 5, 15)

        worksheet.set_row(0, 30)

        row = 4
        column = 0
        room_line = self.env['room.booking.line'].search([('line_ids', '=', False)])
        room_line.onchange_and_take_line_data()
        if self.report_type == 'per_day':
            worksheet.merge_range('C1:I1', 'Room Per Day Report', merge_format)
            month_last_date = self.month_date.replace(
                day=calendar.monthrange(self.month_date.year, self.month_date.month)[1])
            month_first_date = datetime(self.month_date.year, self.month_date.month, 1).date()
            room_ids = self.env['hotel.room'].search([])
            column = 0
            worksheet.write(row, column, "Room", cell_format)

            column += 1
            for i in range(1, month_last_date.day + 1):
                worksheet.write(row, column, i, cell_format)
                column += 1
            row += 1
            for room_id in room_ids:
                column = 0
                worksheet.write(row, column, room_id.name, cell_format)
                column += 1
                book_line_ids = self.env['date.wise.room.booking'].search(
                    [('room_id', '=', room_id.id), ('date', '<=', month_last_date), ('date', '>=', month_first_date)])

                for book in book_line_ids:
                    # if month_last_date.month ==
                    worksheet.write(row, book.date.day, 'Booked', cell_format1)
                row += 1

        elif self.report_type == 'per_day_revenue':
            worksheet.merge_range('C1:I1', 'Room Per Day Report', merge_format)
            month_last_date = self.month_date.replace(
                day=calendar.monthrange(self.month_date.year, self.month_date.month)[1])
            month_first_date = datetime(self.month_date.year, self.month_date.month, 1).date()
            room_ids = self.env['hotel.room'].search([])
            column = 0
            worksheet.write(row, column, "Room", cell_format)

            column += 1
            for i in range(1, month_last_date.day + 1):
                worksheet.write(row, column, i, cell_format)
                column += 1
            row += 1
            for room_id in room_ids:
                column = 0
                worksheet.write(row, column, room_id.name, cell_format)
                column += 1
                book_line_ids = self.env['date.wise.room.booking'].search(
                    [('room_id', '=', room_id.id), ('date', '<=', month_last_date), ('date', '>=', month_first_date)])

                for book in book_line_ids:
                    # if month_last_date.month ==
                    worksheet.write(row, book.date.day, book.room_booking_line_id.price, cell_format1)
                row += 1

        workbook.close()
        export_id = base64.b64encode(open('/tmp/' + file_path, 'rb+').read())
        result_id = self.env['booking.report.wizard'].create(
            {'file': export_id, 'file_name': name_of_file})
        return {
            'name': 'Booking Report',
            'view_mode': 'form',
            'res_id': result_id.id,
            'res_model': 'booking.report.wizard',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'target': 'new',
        }
