from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class AdvancePaymentWizard(models.TransientModel):
    _name = 'create.booking.wizard'
    _description = "Advance Payment Wizard"

    inquiry_id = fields.Many2one('booking.inquiry', string='Booking Inquiry')
    hall_id = fields.Many2one('hall.hall', string="Hall")
    room_ids = fields.Many2many('hotel.room', 'rel_wizard_room', 'wizard_id', 'room_id', string="Room")
    inquiry_for = fields.Selection([('room', 'Room'), ('hall', 'Hall'), ('Restaurant', 'Restaurant')],
                                   string='Inquiry For')

    @api.model
    def default_get(self, fields):
        res = super(AdvancePaymentWizard, self).default_get(fields)
        inquiry_id = self.env['booking.inquiry'].browse(self._context.get('active_id'))
        res['inquiry_id'] = inquiry_id.id
        res['inquiry_for'] = inquiry_id.inquiry_for
        return res

    def action_create_booking(self):
        if not self.inquiry_id.partner_id:
            partner_id1 = self.env['res.partner'].search(
                [('name', '=', self.inquiry_id.inquiry_name), ('phone', '=', self.inquiry_id.phone),
                 ('email', '=', self.inquiry_id.email)], limit=1)
            if partner_id1:
                partner_id = partner_id1
            else:
                partner_id = self.env['res.partner'].create({
                    'name': self.inquiry_id.inquiry_name,
                    'phone': self.inquiry_id.phone,
                    'email': self.inquiry_id.email,
                    'is_customer': True
                })
            self.inquiry_id.partner_id = partner_id
        if self.inquiry_id.payment_ids:
            any_deposit = True
            deposit = sum([x.amount for x in self.inquiry_id.payment_ids])
            journal_id = self.inquiry_id.payment_ids[0].journal_id.id
        else:
            any_deposit = False
            journal_id = False
            deposit = 0
        if self.inquiry_for == 'hall':
            booking_id = self.env['hall.booking'].create({
                'inquiry_id': self.inquiry_id.id or False,
                'partner_id': self.inquiry_id.partner_id.id or False,
                'company_id': self.inquiry_id.company_id.id or False,
                'start_date': self.inquiry_id.arrival_date,
                'end_date': self.inquiry_id.departure_date,
                'booking_time': self.inquiry_id.booking_time,
                'capacity': self.inquiry_id.capacity,
                'hall_id': self.hall_id.id,
                'price': self.hall_id.price,
                'any_deposit': any_deposit,
                'deposit': deposit,
                'journal_id': journal_id,
            })
            if booking_id:
                self.inquiry_id.state = 'booking'
            form_id = self.env.ref('advance_hotel_management_app.hall_booking_form_view').id
            return {'type': 'ir.actions.act_window',
                    'name': _('Hall Booking'),
                    'res_model': 'hall.booking',
                    'view_mode': 'form',
                    'views': [(form_id, 'form')],
                    'domain': [('id', '=', booking_id.id)],
                    'res_id': booking_id.id
                    }

        elif self.inquiry_for == 'Restaurant':
            booking_id = self.env['table.booking'].create({
                'inquiry_id': self.inquiry_id.id or False,
                'partner_id': self.inquiry_id.partner_id.id or False,
                'company_id': self.inquiry_id.company_id.id or False,
                'start_date': self.inquiry_id.arrival_date,
                'end_date': self.inquiry_id.departure_date,
            })
            if booking_id:
                self.inquiry_id.state = 'booking'
            form_id = self.env.ref('advance_hotel_management_app.table_booking_form_view').id
            return {'type': 'ir.actions.act_window',
                    'name': _('Table Booking'),
                    'res_model': 'table.booking',
                    'view_mode': 'form',
                    'views': [(form_id, 'form')],
                    'domain': [('id', '=', booking_id.id)],
                    'res_id': booking_id.id
                    }

        elif self.inquiry_for == 'room':
            room_vals = []
            for room_id in self.room_ids:
                vals = {
                    'room_id': room_id.id,
                    'capacity': room_id.capacity,
                    'room_facility_ids': room_id.room_facility_ids.ids,
                    'price': room_id.price,
                    'uom_id': room_id.uom_id.id,
                    'checkin_date': self.inquiry_id.arrival_date,
                    'checkout_date': self.inquiry_id.departure_date,
                }
                room_vals.append((0, 0, vals))

            booking_id = self.env['room.booking'].create({
                'inquiry_id': self.inquiry_id.id or False,
                'partner_id': self.inquiry_id.partner_id.id or False,
                'company_id': self.inquiry_id.company_id.id or False,
                # 'breakfast': self.inquiry_id.breakfast,
                # 'lunch': self.inquiry_id.lunch,
                # 'dinner': self.inquiry_id.lunch,
                'child': self.inquiry_id.child,
                'adult': self.inquiry_id.person,
                'deposit_amount': deposit,
                'room_line_ids': room_vals,
            })
            if booking_id:
                self.inquiry_id.state = 'booking'
            form_id = self.env.ref('advance_hotel_management_app.room_booking_form_view').id
            return {'type': 'ir.actions.act_window',
                    'name': _('Booking'),
                    'res_model': 'room.booking',
                    'view_mode': 'form',
                    'views': [(form_id, 'form')],
                    'domain': [('id', '=', booking_id.id)],
                    'res_id': booking_id.id
                    }
        else:
            raise ValidationError('Please select one inquiry for')
