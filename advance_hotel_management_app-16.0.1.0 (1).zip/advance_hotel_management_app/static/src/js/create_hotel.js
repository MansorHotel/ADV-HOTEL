odoo.define('advance_hotel_management_app.orders', function (require) {
"use strict";

	$(document).ready(function() {
		$(".wpo_submit_btn").click(function (e){
			if (validateForm("wpo_form")){
				document.getElementById("wpo_form").submit();
			}
			else{
				document.getElementById("check_filled_warn").style.display = "block";
			}

		});

		function validateForm(id) {
			var x, y, i, valid = true;
			x = document.getElementById(id);
			y = x.getElementsByClassName("check_filled");
			for (i = 0; i < y.length; i++) {
				if (y[i].value == "") {
				  y[i].style.backgroundColor = "#ffdddd";
				  valid = false;
				}
				else{
					y[i].style.backgroundColor = "#ffffff";
				}
			}
			return valid;
		};
	});


});

