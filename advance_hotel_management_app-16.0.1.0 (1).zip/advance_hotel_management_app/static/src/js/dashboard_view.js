odoo.define('advance_hotel_management_app.Dashboard',function(require){
"use strict";

var AbstractAction = require('web.AbstractAction');
var ajax = require('web.ajax');
var core = require('web.core');
var Dialog = require('web.Dialog');
var field_utils = require('web.field_utils');
var session = require('web.session');
var web_client = require('web.web_client');
var Widget = require('web.Widget');
var rpc = require('web.rpc');

var _t = core._t;
var QWeb = core.qweb;

var Dashboard = AbstractAction.extend({
	hasControlPanel: true,
	contentTemplate: 'advance_hotel_management_app.Dashboard',

	events: {
	    'click .zoom': 'on_click_list',
	    'click .vehicle': 'on_click_list',
	    'change .stage_name': 'on_click_list',
		'click .column': 'on_click_list',
		'click .form_view' : 'on_click_form',
	},

	init: function(parent, context) {
		this._super(parent, context);
		this.dashboard_stage_templates = ['advance_hotel_management_app.dashboard_view'];
//		this.dashboard_order_templates = ['advance_hotel_management_app.orders'];
	},
	willStart: function() {
		var self = this;
		this._super.apply(this, arguments)
		// var res =  Promise.all([, def]);


			return self.fetch_data();
	},

	start: function() {
		var self = this;
		self.render_dashboards();
		return this._super();
	},

	fetch_data: function() {
		var self = this;
		var prom = this._rpc({
			route: '/hotel/fetch_dashboard_data',
		});
		prom.then(function(result) {
//			self.data = result['reservation_ids'];
			self.room_booking = result['room_booking'];
			self.draft_inquiry = result['draft_inquiry'];
			self.today_in = result['today_in'];
			self.today_out = result['today_out'];
			self.company_name = result['company_name'];
			self.hall_booking = result['hall_booking'];
			self.laundry = result['laundry'];
			self.transport = result['transport'];
			self.housekeeping = result['housekeeping'];
			self.room_order = result['room_order'];
			self.table_booking = result['table_booking'];
			self.order = result['order'];
			self.available = result['available'];
			self.employee = result['employee'];
			self.attendance = result['attendance'];
			self.leave = result['leave'];
		});
		return prom;
	},

	render_dashboards: function() {
		var self = this;
		_.each(this.dashboard_stage_templates, function(template) {
			self.$('.o_dashboard_stage').append(QWeb.render(template, {widget: self}));
		});
	},


on_click_list: function (ev){
		var self = this;
            var model_name = $(ev.currentTarget).find('.name').text();
		var model = '';
		var name = '';
		var stage_name;
		var user = session.uid
		var model_view = '';
		var state = '';
		var $link = $('.zoom');
		var currentDate = new Date();
        var yesterday = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
        var tomorrow = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
		if (ev.currentTarget.firstElementChild && ev.currentTarget.firstElementChild.firstElementChild){
			stage_name = ev.currentTarget.firstElementChild.firstElementChild.innerText;
		}
        state = stage_name.toLowerCase();

        if ($.trim(state) == 'room booking'){
                self.do_action({
                    name: 'Room Booking',
                    views: [[false, 'list'], [false, 'form']],
                    res_model: 'room.booking',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }
        if ($.trim(state) == 'draft inquiry'){
                self.do_action({
                    name: 'Draft Inquiry',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [["state", "=", 'draft']],
                    res_model: 'booking.inquiry',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

         let yesDay= String(yesterday.getDate()).padStart(2, '0');
            let yesMonth = String(yesterday.getMonth()+1).padStart(2,"0");
            let yesYear = yesterday.getFullYear();
            // we will display the date as DD-MM-YYYY
        let yesterday_date = `${yesDay}-${yesMonth}-${yesYear}`;
        let tomDay= String(tomorrow.getDate()).padStart(2, '0');
            let tomMonth = String(tomorrow.getMonth()+1).padStart(2,"0");
            let tomYear = tomorrow.getFullYear();
            // we will display the date as DD-MM-YYYY
        let tomorrow_date = `${tomDay}-${tomMonth}-${tomYear}`;
        if ($.trim(state) == 'today checkin'){
                self.do_action({
                    name: 'Today Checkin',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [['checkin_date', '>', yesterday_date], ['checkin_date', '<', tomorrow_date]],
                    res_model: 'room.booking.line',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

        if ($.trim(state) == 'today checkout'){
                self.do_action({
                    name: 'Today Checkout',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [['checkout_date', '>', yesterday_date], ['checkout_date', '<', tomorrow_date]],
                    res_model: 'room.booking.line',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

        if ($.trim(state) == 'hall booking'){
                self.do_action({
                    name: 'Hall Booking',
                    views: [[false, 'list'], [false, 'form']],
                    res_model: 'hall.booking',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

        if ($.trim(state) == 'laundry'){
                self.do_action({
                    name: 'Laundry',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [["state", "in", ['request', 'process']]],
                    res_model: 'hotel.laundry',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

        if ($.trim(state) == 'transport'){
                self.do_action({
                    name: 'Transport',
                    views: [[false, 'list'], [false, 'form']],
                    res_model: 'transport.service',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

        if ($.trim(state) == 'housekeeping'){
                self.do_action({
                    name: 'Housekeeping',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [["state", "in", ['assign', 'process']]],
                    res_model: 'housekeeping.service',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }
        if ($.trim(state) == 'room order'){
                self.do_action({
                    name: 'Room Order',
                    views: [[false, 'list'], [false, 'form']],
                    res_model: 'room.restaurant',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }
        if ($.trim(state) == 'table booking'){
                self.do_action({
                    name: 'Table Booking',
                    views: [[false, 'list'], [false, 'form']],
                    res_model: 'table.booking',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }
         if ($.trim(state) == 'order'){
                self.do_action({
                    name: 'Order',
                    views: [[false, 'list'], [false, 'form']],
                    res_model: 'table.order',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }
          if ($.trim(state) == 'table available'){
                self.do_action({
                    name: 'Table Available',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [["state", "=", 'free']],
                    res_model: 'table.number',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

          if ($.trim(state) == 'staff'){
                self.do_action({
                    name: 'Staff',
                    views: [[false, 'kanban'],[false, 'list'], [false, 'form']],
                    res_model: 'hr.employee',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

          if ($.trim(state) == 'today attendance'){
                self.do_action({
                    name: 'Today Attendance',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [['check_in', '>', yesterday], ['check_in', '<', tomorrow]],
                    res_model: 'hr.attendance',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }
          let currentDay= String(currentDate.getDate()).padStart(2, '0');
            let currentMonth = String(currentDate.getMonth()+1).padStart(2,"0");
            let currentYear = currentDate.getFullYear();

            // we will display the date as DD-MM-YYYY

        let currentDates = `${currentDay}-${currentMonth}-${currentYear}`;
          if ($.trim(state) == 'today leave'){
                self.do_action({
                    name: 'Today Leave',
                    views: [[false, 'list'], [false, 'form']],
                    domain: [['date_from', '<=', currentDates], ['date_to', '>=', currentDates]],
                    res_model: 'hr.leave',
                    type: 'ir.actions.act_window',
                    target: 'current',
                });
            }

	},
});

core.action_registry.add('advance_hotel_management_dashboard', Dashboard);

return Dashboard;
});